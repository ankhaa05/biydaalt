const mysql = require('mysql');
const express = require('express');
const session = require('express-session');
const path = require('path');

var connectDatabase = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'Temka2467',
    database:'tvmvlvndb'
})
connectDatabase.connect(function(error){
    if(error){
        console.log('Database not connected')
    }
    else{
        console.log('Database connected')
    }
});

const app = express();
app.use(express.json());

app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'static')));

app.get('/register', function(request, response) {
	response.sendFile(path.join(__dirname + '/register.html'));
});
app.post('/registeract', function(request, response){
    let fname = request.body.fname;
    let lname = request.body.lname;
    let age = request.body.age;
    let scode = request.body.scode;
    if(fname && lname && age && scode){
        connectDatabase.query('INSERT INTO students (firstname, lastname, age, studentcode) VALUES (?,?,?,?)',[fname,lname,age,scode], function(error, results, fields){
            if(error){
                console.log('Reg failed');
            }else{
                console.log('Reg successfull')
            }
        });
    }
    response.end();
});
app.get('/search', function(request, response){
response.sendFile(path.join(__dirname + '/search.html'));
});
app.post('/searchact', function(request, response) {
	let id = request.body.id;
	if (id) {
		connectDatabase.query('SELECT * FROM students WHERE studentcode = ?', [id], function(error, results, fields) {
			if (error) throw error;
			if (results.length > 0) {
				console.log(results);
			} else {
				response.send('Incorrect ID!');
			}			
			response.end();
		});
	} else {
		response.send('Please enter ID!');
		response.end();
	}
});
app.listen(6060);
